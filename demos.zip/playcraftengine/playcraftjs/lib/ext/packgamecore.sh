java -jar ~/Dev/yuicompressor-2.4.7.jar src/gamecore.js >> gamecore.min.js
java -jar ~/Dev/yuicompressor-2.4.7.jar src/linkedlist.js >> gamecore.min.js
java -jar ~/Dev/yuicompressor-2.4.7.jar src/pooled.js >> gamecore.min.js
java -jar ~/Dev/yuicompressor-2.4.7.jar src/jhashtable.js >> gamecore.min.js
java -jar ~/Dev/yuicompressor-2.4.7.jar src/device.js >> gamecore.min.js
java -jar ~/Dev/yuicompressor-2.4.7.jar src/class.js >> gamecore.min.js
java -jar ~/Dev/yuicompressor-2.4.7.jar src/perf.js >> gamecore.min.js

