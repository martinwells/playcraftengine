pc.Editor = pc.Base('pc.Editor',
    { },
    {
        sceneList:null,
        sceneStore:null,
        worldPanel:null,

        init:function ()
        {
            this._super();
        },

        onPauseClick:function (button, event)
        {
            theGame.togglePauseResume();

            if (theGame.paused)
                button.setIconCls('icon_resume');
            else
                button.setIconCls('icon_pause');

            this.refreshScenes();
        },

        refreshScenes:function ()
        {
            // create the scenes list
            var scenes = [];
            var next = pc.system.game.getFirstScene();
            while (next)
            {
                scenes.push([next.obj.name]);
                next = next.next();
            }
            this.sceneStore.loadData(scenes);

        },

        onReady:function ()
        {
            Ext.require(['*']);
            Ext.onReady(this.extOnReady.bind(this));
        },

        extOnReady:function ()
        {
            Ext.QuickTips.init();

            // Simple state management. During development,
            // it is generally best to disable state management as dynamically-generated ids
            // can change across page loads, leading to unpredictable results.  The developer
            // should ensure that stable state ids are set for stateful components in real apps.
            Ext.state.Manager.setProvider(Ext.create('Ext.state.CookieProvider'));

            var viewport = Ext.create('Ext.Viewport',
                {
                    layout:'border',
                    align:'stretch',
                    pack:'start'

                });

            // menu
            var menuPanel = Ext.create('Ext.Component', {
                region:'north',
                height:44,
                contentEl:'north'
            });

            viewport.add(menuPanel);

            // tools tab-panel - right hand side big panel
            var toolsPanel = new Ext.Panel({
                region:'east',
                //                    layout: 'border',
                title:'Edit',
                animCollapse:true,
                collapsible:true,
                split:true,
                //                    width:'20%', // give east and west regions a width
                minSize:175,
                maxSize:400,
                margins:'0 5 0 0'
            });

            // controls toolbar
            var controlsToolbar = new Ext.Toolbar({
                id:'controls',
                layoutOnTabChange:true,
                deferredRender:false,
                defaults:{ border:false },
                dock:'top',
                border:false,
                items:[ '->',
                        {
                            xtype:'button', id:'reset', text:'Reset', iconCls:'icon_reset', tooltip:'Restart game',
                            listeners:{
                                click:function (button, event)
                                {
                                    theGame.reset();
                                }
                            }
                        },
                        {
                            xtype:'button', id:'pause', text:'', enableToggle:'true', iconCls:'icon_pause', tooltip:'Pause/resume game',
                            listeners: { click:this.onPauseClick }
                        }
                ]

            });

            toolsPanel.add(controlsToolbar);

            var explorerTabPanel = new Ext.TabPanel({
                region:'east', title:'Explorer', animCollapse:true, collapsible:true, split:true,
                //                    width:225, // give east and west regions a width
                //                    minSize:175, maxSize:400,
                layout:'border', forceFit:true,
                flex:2,
                width: '20%',
                margins:'0 5 0 0', activeTab:1, tabPosition:'top'
            });


            var myData = [
                ['1']
            ];

            this.sceneStore = Ext.create('Ext.data.ArrayStore', {
                fields:[{name:'Name'}],
                data:myData
            });

            this.sceneList = Ext.create('Ext.grid.Panel', {
                store:this.sceneStore,
                stateful:true,
                stateId:'stateGrid',
                layout:'hbox',
                maxWidth:1000,
                minWidth:200,
                columns:[
                    {
                        text:'Name',
                        sortable:false,
                        dataIndex:'Name',
                        minWidth:200
                    }
                ],
                title:'Scenes',
                viewConfig:{
                    stripeRows:true,
                    forceFit:true
                }
            });


            explorerTabPanel.add(this.sceneList);

            this.worldPanel = new Ext.Panel({
                region:'west', title:'Game', animCollapse:true, collapsible:true, split:true,
                width:'80%', // give east and west regions a width
                flex:1,
                html:'<canvas id="gameCanvas"></canvas></div>'
                //                    minSize:175, margins:'0 5 0 0', activeTab:1, tabPosition:'top'
            });

            toolsPanel.add(explorerTabPanel);

            viewport.add(worldPanel);
            viewport.add(toolsPanel);
            viewport.doLayout();

        } // document.onReady

});












            /*
             ,
             {
             id:'playcraft-editor',
             layout:'border',
             items:[
             {
             xtype:'tabpanel',
             region:'east',
             title:'Controls',
             dockedItems:[
             {
             dock:'top',
             xtype:'toolbar',
             items:[ '->',
             {
             xtype:'button', id:'reset', text:'Reset', iconCls:'icon_reset', tooltip:'Restart game',
             listeners:{
             click:function (button, event)
             {
             theGame.reset();
             }
             }
             },
             {
             xtype:'button', id:'pause', text:'', enableToggle:'true', iconCls:'icon_pause', tooltip:'Pause/resume game',
             listeners:{
             click:function (button, event)
             {
             theGame.togglePauseResume();

             if (theGame.paused)
             button.setIconCls('icon_resume');
             else
             button.setIconCls('icon_pause');
             }
             }
             }
             ]
             }
             ],
             animCollapse:true,
             collapsible:true,
             split:true,
             width:225, // give east and west regions a width
             minSize:175,
             maxSize:400,
             margins:'0 5 0 0',
             activeTab:1,
             tabPosition:'bottom',
             items:[
             {
             html:'<p>A TabPanel component can be a region.</p>',
             title:'A Tab',
             autoScroll:true
             },
             Ext.create('Ext.grid.PropertyGrid', {
             title:'Property Grid',
             closable:true,
             source:{
             "Entity":"PlayerShip",
             "Pos":"106,210",
             "Active":true
             }
             })
             ]
             },
             {
             region:'west',
             stateId:'navigation-panel',
             id:'west-panel', // see Ext.getCmp() below
             title:'Content',
             split:true,
             width:200,
             minWidth:175,
             maxWidth:400,
             collapsible:true,
             animCollapse:true,
             margins:'0 0 0 5',
             layout:'accordion',
             items:[
             {
             contentEl:'west',
             title:'Hierarchy',
             iconCls:'nav' // see the HEAD section for style used
             },
             {
             title:'Debug/Profile',
             html:'<p></p>',
             iconCls:'settings'
             }
             ]
             },
             // in this instance the TabPanel is not wrapped by another panel
             // since no title is needed, this Panel is added directly
             // as a Container
             {
             region:'center',
             layout:'border',
             items:[
             Ext.create('Ext.tab.Panel', {
             region:'center', // a center region is ALWAYS required for border layout
             deferredRender:false,
             activeTab:0, // first tab initially active
             items:[
             {
             contentEl:'center1',
             title:'Game',
             closable:true,
             autoScroll:true,
             listeners:{
             resize:{
             fn:function (el)
             {
             if (el.body.dom.clientWidth)
             pc.system.resize(el.body.dom.clientWidth, el.body.dom.clientHeight);
             }
             }
             },

             },
             {
             contentEl:'center2',
             title:'Map - test1',
             autoScroll:true
             }
             ]
             }),
             {
             region:'south',
             contentEl:'stats',
             split:true,
             layout:'fit',
             listeners:{
             resize:{
             fn:function (el)
             {
             if (el.body.dom.clientWidth)
             pc.system.debugPanel.onResize(el.body.dom.clientWidth, el.body.dom.clientHeight);
             }
             }
             },
             height:200,
             minSize:100,
             maxSize:200,
             collapsible:true,
             collapsed:false,
             title:'Debug',
             margins:'0 0 0 0'
             }

             ]
             }
             ]
             });

             //        var el = Ext.get('stats');
             //        pc.system.debugPanel.resize(el.dom.clientWidth, el.dom.clientHeight);

             */