closure-library/closure/bin/build/closurebuilder.py \
  --root=closure-library/ \
  --root="src/" \
  --namespace="Box2d" \
  --output_mode=compiled \
  --compiler_jar=compiler.jar \
  > box2d-pc-min.js
